import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.effect.*;
import javafx.scene.text.*;
import java.io.File;
import java.net.MalformedURLException;
import java.util.*;
import java.io.*;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.nio.file.*;

public class PantryPrequel extends Application {
	
	Stage mainStage = new Stage();
	Stage infoStage = new Stage();
	Stage settingsStage = new Stage();
	Stage foodStage = new Stage();
	Stage searchStage = new Stage();
	Stage expSoonStage = new Stage();
	int x = 0;
	
	protected BorderPane getMenu() throws MalformedURLException{
		AddFood adding = new AddFood();
		
		//declare panes
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(10,10,0,10));
		FlowPane pantryPane = new FlowPane();
		pantryPane.setHgap(5);
		pantryPane.setVgap(5);
		pantryPane.setPadding(new Insets(10, 0, 20, 0));
		ScrollPane pantryScrollPane = new ScrollPane();
		pantryScrollPane.setContent(pantryPane);
		pantryScrollPane.setPadding(new Insets(10, 10, 0, 10));
		pantryScrollPane.getStylesheets().add("style.css");
		pantryScrollPane.setFitToWidth(true);
		pantryScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
		GridPane topPane = new GridPane();
		pane.setTop(topPane);
		pane.setCenter(pantryScrollPane);
		
		//Background images
		Image bgImg = new Image(getClass().getResourceAsStream("woodBg.png"),560,800,false,true);
		BackgroundImage paneBg = new BackgroundImage(bgImg,BackgroundRepeat.REPEAT,
				BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
		pane.setBackground(new Background(paneBg));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(3);
		dropShadow.setOffsetY(3);
		DropShadow dropShadow1 = new DropShadow();
		dropShadow1.setRadius(5);
		dropShadow1.setOffsetX(-5);
		dropShadow1.setOffsetY(9);
		dropShadow1.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//Add logo
		Image logoImg = new Image(new File("PantryLogo.png").toURI().toURL().toExternalForm());
		ImageView logoIV = new ImageView(logoImg);
		double W = logoImg.getWidth();
		double H = logoImg.getHeight();
		double G = W;
		if (H > W)
			G = H;
		double R = G / 300.0;
		int nW = (int) Math.round(W / R);
		int nH = (int) Math.round(H / R);
		logoIV.setFitWidth(nW);
		logoIV.setFitHeight(nH);
		logoIV.setEffect(dropShadow1);
		
		//Set up topPane with logo and buttons
		VBox buttonPane = new VBox(5);
		buttonPane.setPadding(new Insets(0, 80, 0, 0));
		Button settingsBt = new Button("Settings");
		settingsBt.setEffect(dropShadow);
		Button infoBt = new Button("About");
		infoBt.setEffect(dropShadow);
		buttonPane.getChildren().addAll(settingsBt, infoBt);
		topPane.add(buttonPane, 0, 0);
		topPane.add(logoIV, 1, 0);
		
		//lamda functions for settings and info buttons
		settingsBt.setOnAction(e -> {
			Scene settingsScene = new Scene(settingsPane(paneBg), 400, 500);
			settingsStage.setTitle("Settings");
			settingsStage.setScene(settingsScene);
			settingsStage.setResizable(false);
			settingsStage.show();
		});
		
		infoBt.setOnAction(e -> {
			Scene infoScene = new Scene(infoPane(paneBg), 400, 500);
			infoStage.setTitle("About");
			infoStage.setScene(infoScene);
			infoStage.setResizable(false);
			infoStage.show();
		});
		
		//pantry buttons
		String[] foodList;
		if (getFromPantry() == null) {
			foodList = new String[0];
		} else {
			foodList = getFromPantry();
		}
		Button[] buttons = new Button[foodList.length];
		Image[] foodImg = new Image[foodList.length];
		ImageView[] foodIV = new ImageView[foodList.length];
		for(int i = 0; i < foodList.length; i++) {
			String[] food = getPantryItem(foodList[i]);
			foodImg[i] = new Image(new File(food[3]).toURI().toURL().toExternalForm());
			foodIV[i] = new ImageView(foodImg[i]);
			double w = foodImg[i].getWidth();
			double h = foodImg[i].getHeight();
			double g = w;
			if (h > w)
				g = h;
			double r = g / 45.0;
			int nw = (int) Math.round(w / r);
			int nh = (int) Math.round(h / r);
			foodIV[i].setFitWidth(nw);
			foodIV[i].setFitHeight(nh);
			buttons[i] = new Button(food[0], foodIV[i]);
			buttons[i].setTextAlignment(TextAlignment.CENTER);
			buttons[i].setContentDisplay(ContentDisplay.TOP);
			buttons[i].setWrapText(true);
			buttons[i].setPrefSize(100, 100);
			buttons[i].setEffect(dropShadow);
			pantryPane.getChildren().add(buttons[i]);
			
			final int ii = i;
			buttons[i].setOnAction( e -> {
				mainStage.close();
				
				Scene foodScene = new Scene(foodPane(paneBg, food, ii, foodList), 400, 500);
				foodStage.setTitle("About");
				foodStage.setScene(foodScene);
				foodStage.setResizable(false);
				foodStage.show();
			});
		}
		
		//check for upcoming exp dates
		String[] expSoon = checkExpDates(foodList);
		if(expSoon.length > 0 && x == 0) {
			x = 1;
			Scene expSoonScene = new Scene(expSoonPane(paneBg, expSoon), 400, 500);
			expSoonStage.setTitle("Suggested Actions");
			expSoonStage.setScene(expSoonScene);
			expSoonStage.setResizable(false);
			expSoonStage.show();
		}
		
		//add button
		Image addImg = new Image(getClass().getResourceAsStream("add.png"));
		ImageView addIV = new ImageView(addImg);
		addIV.setFitHeight(50);
		addIV.setFitWidth(50);
		Button addBtn = new Button("Add a New Grocery Item", addIV);
		addBtn.setTextAlignment(TextAlignment.CENTER);
		addBtn.setContentDisplay(ContentDisplay.TOP);
		addBtn.setPrefSize(100,100);
		addBtn.setWrapText(true);
		addBtn.setEffect(dropShadow);
		pantryPane.getChildren().add(addBtn);
		
		Image searchImg = new Image(getClass().getResourceAsStream("search.png"));
		ImageView searchIV = new ImageView(searchImg);
		searchIV.setFitHeight(50);
		searchIV.setFitWidth(50);
		Button searchBtn = new Button("Search for recipes", searchIV);
		searchBtn.setTextAlignment(TextAlignment.CENTER);
		searchBtn.setContentDisplay(ContentDisplay.TOP);
		searchBtn.setPrefSize(100,100);
		searchBtn.setWrapText(true);
		searchBtn.setEffect(dropShadow);
		pantryPane.getChildren().add(searchBtn);
		
		addBtn.setOnAction(e -> {
			mainStage.close();
			Stage addStage = new Stage();
			try{
				adding.start(addStage);
			}catch (Exception m){
				m.printStackTrace();
			}
		});
		
		searchBtn.setOnAction(e -> {
			mainStage.close();
			
			Scene searchScene = new Scene(searchPane(paneBg, foodList), 400, 500);
			searchStage.setTitle("Find Recipes");
			searchStage.setScene(searchScene);
			searchStage.setResizable(false);
			searchStage.show();
		});
		
		return pane;
	}
	
	public StackPane searchPane(BackgroundImage bgImg, String[] foodList){
		//set up scene
		StackPane pane = new StackPane();
		VBox mainPane = new VBox(10);
		pane.setBackground(new Background(bgImg));
		mainPane.setAlignment(Pos.TOP_CENTER);
		mainPane.setPadding(new Insets(40,45,45,40));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//note image
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		//close button
		HBox closePane = new HBox();
		closePane.setPadding(new Insets(10,10,0,0));
		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> {
			searchStage.close();
			try{
				start(mainStage);
			} catch (Exception m) {
				m.printStackTrace();
			}
		});
		closePane.getChildren().add(closeBtn);
		
		//title label
		Label titleLbl = new Label("Search For Recipes With Items");
		Label titleLbl1 = new Label("From Your Pantry");
		titleLbl1.setStyle("-fx-font: 21 arial;");
		titleLbl.setStyle("-fx-font: 21 arial;");
		
		//include section
		VBox includePane = new VBox(10);
		Label includeLbl = new Label("Include: ");
		TextField includeTF = new TextField();
		includePane.getChildren().addAll(includeLbl, includeTF);
		
		//exclude section
		VBox excludePane = new VBox(10);
		Label excludeLbl = new Label("Exclude: ");
		TextField excludeTf = new TextField();
		excludePane.getChildren().addAll(excludeLbl, excludeTf);
		
		//search button
		HBox btnPane = new HBox(10);
		btnPane.setAlignment(Pos.CENTER_RIGHT);
		Button searchBtn = new Button("Search");
		searchBtn.setOnAction(e -> {
			String includeText = includeTF.getText().replace(", ", ",");
			includeText = includeText.replace(" ", "%20");
			String excludeText = excludeTf.getText().replace(", ", ",");
			excludeText = excludeText.replace(" ", "%20");
			String searchStr = "http://www.allrecipes.com/search/results/?ingIncl=" + includeText + "&ingExcl=" + excludeText + "&sort=re";
			getHostServices().showDocument(searchStr);
		});
		
		Button clearButton = new Button("Clear");
		clearButton.setOnAction(e -> {
			includeTF.setText("");
			excludeTf.setText("");
		});
		btnPane.getChildren().addAll(clearButton, searchBtn);
		
		//data for list view
		String[] foodNames = new String[foodList.length];
		for(int i = 0; i < foodList.length; i++){
			String[] pantryItem = getPantryItem(foodList[i]);
			foodNames[i] = pantryItem[1];
			foodNames[i] += " (Expires: ";
			foodNames[i] += pantryItem[2];
			foodNames[i] += ")";
		}
		
		//list view
		ListView<String> foodListView = new ListView<String>();
		ObservableList<String> items = FXCollections.observableArrayList(foodNames);
		foodListView.setItems(items);
		foodListView.setOnMouseClicked(e -> {
			int add = foodListView.getFocusModel().getFocusedIndex();
			String tempText = includeTF.getText();
			tempText = tempText.trim();
			if (tempText.length() > 0)
				if (tempText.charAt(tempText.length()-1) != ',')
					tempText += ", ";
			tempText += getPantryItem(foodList[add])[1];
			includeTF.setText(tempText);
		});
		
		mainPane.getChildren().addAll(closePane, titleLbl, titleLbl1, includePane, foodListView, excludePane, btnPane);
		pane.getChildren().addAll(noteIV, mainPane);
		
		return pane;
	}
	
	public StackPane foodPane(BackgroundImage bgImg, String[] foodStuff, int i, String[] toTxt) {
		final FileChooser fileChooser = new FileChooser();
		//set up scene
		StackPane pane = new StackPane();
		VBox mainPane = new VBox(10);
		pane.setBackground(new Background(bgImg));
		mainPane.setAlignment(Pos.TOP_CENTER);
		mainPane.setPadding(new Insets(40,35,35,30));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//note image
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		//close button
		HBox closePane = new HBox();
		closePane.setPadding(new Insets(10,10,0,10));
		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> {
			foodStage.close();
			try{
				start(mainStage);
			} catch (Exception m) {
				m.printStackTrace();
			}
		});
		closePane.getChildren().add(closeBtn);
		
		//title
		Label lbTitle = new Label(foodStuff[1]);
		lbTitle.setUnderline(true);
		lbTitle.setStyle("-fx-font: 21 arial;");
		
		//exp date
		HBox expDatePane = new HBox(10);
		expDatePane.setAlignment(Pos.CENTER);
		Label lbExpDate = new Label("Expiration Date: ");
		TextField tfExpDate = new TextField();
		tfExpDate.setText(foodStuff[2]);
		tfExpDate.setPrefColumnCount(6);
		tfExpDate.setEditable(false);
		tfExpDate.setOnMouseClicked(e -> {
			if (tfExpDate.isEditable() == true)
				tfExpDate.setText("");
		});
		Button btExpDate = new Button("Change Date");
		btExpDate.setOnAction(e -> {
			if ("Change Date".equals(btExpDate.getText())) {
				btExpDate.setText("Done");
				tfExpDate.setEditable(true);
			} else {
				if(isValidDate(tfExpDate.getText()) == false) {
					tfExpDate.setText(foodStuff[2]);
				}
				btExpDate.setText("Change Date");
				tfExpDate.setEditable(false);
			}
			if (tfExpDate.getText().equals(foodStuff[2]) == false){
				toTxt[i] = toTxt[i].replaceAll(foodStuff[2], tfExpDate.getText());
				setPantry(toTxt);
			}
			
		});
		expDatePane.getChildren().addAll(lbExpDate, tfExpDate, btExpDate);
		
		//image
		Image foodImg = new Image(getClass().getResourceAsStream(foodStuff[3]));
		ImageView foodIV = new ImageView(foodImg);
		double w = foodImg.getWidth();
		double h = foodImg.getHeight();
		double g = w;
		if (h > w)
			g = h;
		double r = g / 150.0;
		int nw = (int) Math.round(w / r);
		int nh = (int) Math.round(h / r);
		foodIV.setFitWidth(nw);
		foodIV.setFitHeight(nh);
		foodIV.setEffect(dropShadow);
		
		//change image button
		Button changeImgBtn = new Button("Change Image");
		changeImgBtn.setOnAction(e -> {
			//set up file chooser
			File userDirectory = new File("/Users/student/Downloads");
			if(!userDirectory.canRead())
				userDirectory = new File("c:/");
			fileChooser.setInitialDirectory(userDirectory);
			FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png");
			fileChooser.getExtensionFilters().add(extFilter);
			fileChooser.setTitle("Select an Image");
			File file = fileChooser.showOpenDialog(new Stage());
			String fileString = "";
			if (file != null) {
				//copy image to backup folder
				fileString = file.toString();
				Path from = Paths.get(fileString);
				String word = randomWord();
				String pathString = "Custom Images/" + word + ".png";
				Path to = Paths.get(pathString);
				CopyOption[] options = new CopyOption[]{StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES};
				try {
					Files.copy(from, to, options);
				} catch (Exception IOException) {
					System.out.println("File not found");
				}
				//change image in text file
				toTxt[i] = toTxt[i].replaceAll(foodStuff[3], pathString);
				setPantry(toTxt);
			}else 
				fileString = foodStuff[3];
			try {
				//change image
				Image newFoodImg = new Image(new File(fileString).toURI().toURL().toExternalForm());
				foodIV.setImage(newFoodImg);
				double newW = foodImg.getWidth();
				double newH = foodImg.getHeight();
				double newG = newW;
				if (h > w)
					newG = newH;
				double newR = newG / 150.0;
				int newnw = (int) Math.round(newW / newR);
				int newnh = (int) Math.round(newH / newR);
				foodIV.setFitWidth(newnw);
				foodIV.setFitHeight(newnh);
			} catch (Exception MalformedInputException) {
				System.out.println("Image not found");
			}
		});
		
		//Delete item and add to grocery list buttons
		HBox buttonPane = new HBox(20);
		buttonPane.setPadding(new Insets(20,10,0,10));
		buttonPane.setAlignment(Pos.CENTER);
		Image delImg = new Image(getClass().getResourceAsStream("X.png"));
		//Image listImg = new Image(getClass().getResourceAsStream("check list.png"));
		ImageView delIV = new ImageView(delImg);
		//ImageView listIV = new ImageView(listImg);
		delIV.setFitWidth(15);
		delIV.setFitHeight(15);
		//listIV.setFitWidth(11);
		//listIV.setFitHeight(15);
		Button delBtn = new Button("Delete", delIV);
		//Button listBtn = new Button("Add to Shopping list", listIV);
		buttonPane.getChildren().addAll(/*listBtn, */delBtn);
		
		//delete button controls
		delBtn.setOnAction(e -> {
			String[] foodArray = new String[toTxt.length - 1];
			for(int j = 0; j < foodArray.length; j++){
				if (j >= i)
					foodArray[j] = toTxt[j + 1];
				else 
					foodArray[j] = toTxt[j];
			}
			setPantry(foodArray);
			foodStage.close();
			try{
				start(mainStage);
			} catch (Exception m) {
				m.printStackTrace();
			}
		});
		
		//search button
		Image searchImg = new Image(getClass().getResourceAsStream("search.png"));
		ImageView searchIV = new ImageView(searchImg);
		searchIV.setFitWidth(15);
		searchIV.setFitHeight(15);
		Button searchBtn = new Button("Look up recipes containing this item", searchIV);
		searchBtn.setOnAction(e -> {
			String foodSearch = foodStuff[1].replace(" ", "%20");
			String searchStr = "http://www.allrecipes.com/search/results/?ingIncl=" + foodSearch + "&sort=re";
			getHostServices().showDocument(searchStr);
		});
		
		//add children
		mainPane.getChildren().addAll(closePane, lbTitle, foodIV, changeImgBtn, expDatePane, buttonPane, searchBtn);
		pane.getChildren().addAll(noteIV, mainPane);
		
		return pane;
	}
	
	public StackPane settingsPane(BackgroundImage bgImg){
		//set up scene
		StackPane pane = new StackPane();
		VBox mainPane = new VBox(15);
		pane.setBackground(new Background(bgImg));
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(70,35,25,30));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//note image
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		//message
		Label msgLbl = new Label("So sorry, personalization is not yet available.");
		msgLbl.setStyle("-fx-font: 21 arial;");
		msgLbl.setWrapText(true);
		msgLbl.setTextAlignment(TextAlignment.CENTER);
		
		//done button
		HBox btnPane = new HBox(10);
		btnPane.setAlignment(Pos.CENTER_RIGHT);
		Button doneBtn = new Button("Done");
		doneBtn.setOnAction(e -> settingsStage.close());
		btnPane.getChildren().add(doneBtn);
		
		mainPane.getChildren().addAll(msgLbl, btnPane);
		pane.getChildren().addAll(noteIV, mainPane);
		
		return pane;
	}
	
	public StackPane infoPane(BackgroundImage bgImg) {
		//set up scene
		StackPane pane = new StackPane();
		VBox infoPane = new VBox(15);
		pane.setBackground(new Background(bgImg));
		infoPane.setAlignment(Pos.CENTER);
		infoPane.setPadding(new Insets(70,35,25,30));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		//title
		Label lbTitle = new Label("The Pantry Prequel");
		lbTitle.setUnderline(true);
		lbTitle.setStyle("-fx-font: 21 arial;");
		
		//body
		Label lbInfo = new Label("The Pantry Prequel is a digital pantry that helps you keep track of what food you have and when that food is going to expire. Once you've added something to your pantry list you can let your worries fade away, we'll let you know when something is about to expire and we'll even help you find some tasty recipes so that food doesn't go to waste!\n\nTo add another grocery item just click the button with the big orange plus sign on it, you can't miss it!");
		lbInfo.setStyle("-fx-font: 16 arial;");
		lbInfo.setTextAlignment(TextAlignment.CENTER);
		lbInfo.setWrapText(true);
		
		//done button
		HBox btnPane = new HBox(10);
		btnPane.setAlignment(Pos.CENTER_RIGHT);
		Button doneBtn = new Button("Done");
		doneBtn.setOnAction(e -> infoStage.close());
		btnPane.getChildren().add(doneBtn);
		
		infoPane.getChildren().addAll(lbTitle, lbInfo, btnPane);
		pane.getChildren().addAll(noteIV, infoPane);
		
		return pane;
	}
	
	public StackPane expSoonPane(BackgroundImage bgImg, String[] food){
		
		//set up scene
		StackPane pane = new StackPane();
		VBox mainPane = new VBox(5);
		pane.setBackground(new Background(bgImg));
		mainPane.setAlignment(Pos.CENTER);
		mainPane.setPadding(new Insets(80,45,35,40));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//note image
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		//title
		Label lbTitle = new Label("Important!");
		lbTitle.setUnderline(true);
		lbTitle.setStyle("-fx-font: 21 arial;");
		
		//body text
		HBox bodyPane = new HBox();
		Label bodylb = new Label("These items are expiring within the next 7 days:");
		bodylb.setStyle("-fx-font: 14 arial;");
		bodylb.setTextAlignment(TextAlignment.LEFT);
		bodylb.setWrapText(true);
		bodyPane.getChildren().add(bodylb);
		
		//list view
		ListView<String> foodListView = new ListView<String>();
		ObservableList<String> items = FXCollections.observableArrayList(food);
		foodListView.setItems(items);
		
		//body text 2
		VBox bodyPane2 = new VBox();
		Label bodylb2 = new Label("You may want to consider looking up recipes with");
		bodylb2.setStyle("-fx-font: 14 arial;");
		bodylb2.setTextAlignment(TextAlignment.LEFT);
		Label bodylb3 = new Label("these ingredients as soon as possible.");
		bodylb3.setStyle("-fx-font: 14 arial;");
		bodylb3.setTextAlignment(TextAlignment.LEFT);
		bodyPane2.getChildren().addAll(bodylb2, bodylb3);
		
		//buttons
		HBox buttonPane = new HBox(10);
		buttonPane.setAlignment(Pos.CENTER_RIGHT);
		Button closeBtn = new Button("Close");
		Button searchBtn = new Button("Search Recipes");
		buttonPane.getChildren().addAll(closeBtn, searchBtn);
		closeBtn.setOnAction(e -> {
			expSoonStage.close();
		});
		searchBtn.setOnAction(e -> {
			expSoonStage.close();
			
			String includeText = "";
			for(int i = 0; i < food.length; i++){
				includeText += food[i] + ",";
			}
			includeText = includeText.replace(" ", "%20");
			String searchStr = "http://www.allrecipes.com/search/results/?ingIncl=" + includeText + "&sort=re";
			getHostServices().showDocument(searchStr);
		});
		
		mainPane.getChildren().addAll(lbTitle, bodyPane, foodListView, bodyPane2, buttonPane);
		pane.getChildren().addAll(noteIV, mainPane);
		
		return pane;
	}
	
	//check for upcoming exp dates
	public String[] checkExpDates(String[] stuff) {
		String[] dates = new String[stuff.length];
		String[] food = new String[stuff.length];
		for(int i = 0; i < stuff.length; i++){
			dates[i] = getPantryItem(stuff[i])[2];
			food[i] = getPantryItem(stuff[i])[1];
		}
		List<String> expSoon = new ArrayList<String>();
		Calendar expCalendar = new GregorianCalendar();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date dt = new Date();
		expCalendar.setTime(dt);
		expCalendar.add(Calendar.DATE, 7);
		Date beforeDate = expCalendar.getTime();
		for(int i = 0; i < dates.length; i++){
			Date given = new Date();
			try {
				given = dateFormat.parse(dates[i].trim());
			} catch (ParseException pe) {
				System.out.println("Could not parse");
			}
			if(given.before(beforeDate)){
				expSoon.add(food[i]);
			}
		}
		
		String[] expSoonArray = expSoon.toArray(new String[expSoon.size()]);
		return expSoonArray;
	}
	
	public static String randomWord() {
		final String alphabet = "abcdefghijklmnopqrstuvwxyz";
		final int N = alphabet.length();
		
		Random r = new Random();
		String word = "";
			
		for (int i = 0; i < 12; i++){
			word += alphabet.charAt(r.nextInt(N));
		}
		return word;
	}
		
	public static boolean isValidDate(String inDate) {
		Date current = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		Date given = new Date();
		try {
			given = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return false;
		}
		if(given.after(current))
			return true;
		else 
			return false;
	}
	
	public String[] getPantryItem(String foodLine) {
		String[] food = new String[4];
		food[0] = foodLine.substring(0, foodLine.indexOf('$'));
		food[0] += "\n";
		food[0] += foodLine.substring(foodLine.indexOf('$') + 1, foodLine.indexOf('%'));
		food[1] = foodLine.substring(0, foodLine.indexOf('$'));
		food[2] = foodLine.substring(foodLine.indexOf('$') + 1, foodLine.indexOf('%'));
		food[3] = foodLine.substring(foodLine.indexOf('%') + 1);
		
		return food;
	}
	
	public String[] getFromPantry(){
		try {
			Scanner reader = new Scanner(new File("pantry.txt"));
			List<String> food = new ArrayList<String>();
			while (reader.hasNextLine()) {
				food.add(reader.nextLine());
			}
			reader.close();
			String[] foodList = food.toArray(new String[food.size()]);
			return foodList;
		} catch (Exception IOException){
			System.out.println("File not found");
			return null;
		}
	}
	
	public void setPantry(String[] toTxt) {
		try {
			PrintWriter writer = new PrintWriter(new FileOutputStream(new File("pantry.txt")));
			for(int i = 0; i < toTxt.length; i++) {
				writer.println(toTxt[i]);
			} 
			writer.close();
		}catch (Exception IOException) {
				System.out.println("File not found");
		}
	}
	
	@Override
	public void start(Stage primaryStage) throws MalformedURLException {
		mainStage.setTitle("Pantry Prequel");
		Scene mainScene = new Scene(getMenu(), 560, 800);
		mainStage.setScene(mainScene);
		mainStage.setResizable(false);
		mainStage.show();
		expSoonStage.toFront();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
	
}