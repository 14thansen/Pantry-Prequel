import java.awt.Desktop;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.effect.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.io.File;
import java.io.IOException;
import java.net.*;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.ParseException;
import java.io.*;

public class AddFood extends Application {
	Stage addStage = new Stage();
	
	protected StackPane addMenu() throws MalformedURLException{
		//important
		PantryPrequel main = new PantryPrequel();
		final FileChooser fileChooser = new FileChooser();
		//establish time and date
		Calendar calendar = new GregorianCalendar();
		Date date = new Date();
		calendar.setTime(date);
		
		//set up scene
		StackPane pane = new StackPane();
		pane.setPadding(new Insets(10,10,10,10));
		VBox optionsPane = new VBox(5);
		optionsPane.setPadding(new Insets(70,35,25,30));
		
		//drop shadow
		DropShadow dropShadow = new DropShadow();
		dropShadow.setRadius(5);
		dropShadow.setOffsetX(-5);
		dropShadow.setOffsetY(9);
		dropShadow.setColor(Color.color(0.2,0.2,0.2,0.8));
		
		//Background images
		Image bgImg = new Image(getClass().getResourceAsStream("woodBg.png"),1000,15000,false,true);
		BackgroundImage paneBg = new BackgroundImage(bgImg,BackgroundRepeat.REPEAT,
				BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
		pane.setBackground(new Background(paneBg));
		Image noteImg = new Image(getClass().getResourceAsStream("note.png"));
		ImageView noteIV = new ImageView(noteImg);
		noteIV.setFitHeight(450);
		noteIV.setFitWidth(350);
		noteIV.setEffect(dropShadow);
		
		pane.getChildren().addAll(noteIV, optionsPane);
		
		//First line (title)
		VBox line1 = new VBox(5);
		line1.setAlignment(Pos.CENTER);
		Label lbTitle = new Label("The Pantry Prequel");
		lbTitle.setUnderline(true);
		lbTitle.setStyle("-fx-font: 21 arial;");
		Label lbSubTitle = new Label("Add items to the pantry list");
		line1.getChildren().addAll(lbTitle, lbSubTitle);
		
		//second line (type in item)
		HBox line2 = new HBox(10);
		Label typeFoodLabel = new Label("Enter your grocery item: ");
		typeFoodLabel.setWrapText(true);
		TextField tfFood = new TextField();
		tfFood.setText("eg. Mayonnaise");
		tfFood.setStyle("-fx-text-inner-color: gray");
		line2.getChildren().addAll(typeFoodLabel, tfFood);
		
		//third line (or)
		Label line3 = new Label("or");
		
		//forth line (select item)
		HBox line4 = new HBox(10);
		Label selectFoodLable = new Label("Select from most popular grocery items: ");
		selectFoodLable.setWrapText(true);
		String[] popFoods = {"Choose",
							 "Bread",
							 "Sandwich Meat",
							 "Peanut Butter",
							 "Jelly",
							 "Eggs",
							 "Milk",
							 "Potato Chips",
							 "Frozen Dinner",
							 "Cereal",
							 "Soda"};
		int[] popExpDate = {0, 7, 10, 365, 365, 21, 7, 90, 180, 180, 270};
		int[] popFoodPicNo = {0, 17, 7, 2, 3, 11, 4, 1, 7, 18, 3};
		ComboBox<String> cbPopFoods = new ComboBox<>();
		ObservableList<String> items = FXCollections.observableArrayList(popFoods);
		cbPopFoods.getItems().addAll(items);
		cbPopFoods.setValue(popFoods[0]);
		line4.getChildren().addAll(selectFoodLable, cbPopFoods);
		
		//line
		Label lineLbl = new Label("---------------------------------------------------");
		Label lineLbl1 = new Label("---------------------------------------------------");
		Label lineLbl2 = new Label("---------------------------------------------------");
		
		//fifth line (expiration date)
		HBox line5 = new HBox(10);
		VBox expPane = new VBox(10);
		Label expDateLbl = new Label("Please enter the expiration date:");
		Label errorLbl = new Label("");
		errorLbl.setTextFill(Color.RED);
		errorLbl.setWrapText(true);
		expDateLbl.setWrapText(true);
		TextField tfExpDate = new TextField();
		tfExpDate.setPrefColumnCount(6);
		tfExpDate.setText("mm/dd/yyyy");
		tfExpDate.setStyle("-fx-text-inner-color: gray");
		expPane.getChildren().addAll(expDateLbl, errorLbl);
		line5.getChildren().addAll(expPane, tfExpDate);
		
		//sixth line (picture)
		HBox line6 = new HBox(10);
		Label photoLbl = new Label("Choose a photo from a food category:");
		photoLbl.setWrapText(true);
		String[] foodCategoryStrings = {"No Category",
										"Fats",
										"Oils",
										"Sweets",
										"Milk",
										"Yogurt",
										"Cheese",
										"Meats",
										"Poultry",
										"Fish",
										"Beans",
										"Eggs",
										"Nuts",
										"Vegetables",
										"Spices",
										"Herbs",
										"Fruit",
										"Bread",
										"Cereal",
										"Rice",
										"Pasta"};
		String[] foodStrings = {"food categories/miscFood.png",
								"food categories/fats.png",
								"food categories/oils.png",
								"food categories/sweets.png",
								"food categories/milk.png",
								"food categories/yogurt.png",
								"food categories/cheese.png",
								"food categories/meats.png",
								"food categories/poultry.png",
								"food categories/fish.png",
								"food categories/beans.png",
								"food categories/eggs.png",
								"food categories/nuts.png",
								"food categories/vegetables.png",
								"food categories/spices.png",
								"food categories/herbs.png",
								"food categories/fruit.png",
								"food categories/bread.png",
								"food categories/cereal.png",
								"food categories/rice.png",
								"food categories/pasta.png"};
		Image[] foodImgs = new Image[21];
		for(int i = 0; i < 21; i++){
			foodImgs[i] = new Image(getClass().getResourceAsStream(foodStrings[i]));
		}
		ComboBox<String> cbFoodCategories = new ComboBox<>();
		ObservableList<String> categoryItems = FXCollections.observableArrayList(foodCategoryStrings);
		cbFoodCategories.getItems().addAll(categoryItems);
		cbFoodCategories.setValue(foodCategoryStrings[0]);
		ImageView foodIV = new ImageView(foodImgs[0]);
		double w = foodImgs[0].getWidth();
		double h = foodImgs[0].getHeight();
		double g = w;
		if (h > w)
			g = h;
		double r = g / 100.0;
		int nw = (int) Math.round(w / r);
		int nh = (int) Math.round(h / r);
		foodIV.setFitWidth(nw);
		foodIV.setFitHeight(nh);
		VBox innerPane = new VBox(10);
		innerPane.getChildren().addAll(photoLbl, cbFoodCategories);
		line6.getChildren().addAll(innerPane, foodIV);
		
		HBox line7 = new HBox(10);
		line7.setAlignment(Pos.CENTER_RIGHT);
		Button cancelBtn = new Button("Cancel");
		Button donebtn = new Button("Done");
		line7.getChildren().addAll(cancelBtn, donebtn);
		
		optionsPane.getChildren().addAll(line1, line2, line3, line4, lineLbl, line5, lineLbl1, line6, line7);
		
		//object controls
		//changing the expiration date
		tfExpDate.setOnMouseClicked(e -> {
			tfExpDate.setStyle("-fx-text-inner-color: black;" + "-fx-background-color: white;");
			tfExpDate.setText("");
			errorLbl.setText("");
		});
		//changing the popular foods combo box
		cbPopFoods.valueProperty().addListener(new ChangeListener<String>() {
			@Override public void changed(ObservableValue ov, String t, String t1) {
				cbPopFoods.setStyle("-fx-background-color: white;");
				tfFood.setStyle("-fx-background-color: white;" + "-fx-text-inner-color: gray;");
				Calendar expCalendar = new GregorianCalendar();
				Date changeDate = new Date();
				expCalendar.setTime(date);
				if (items.indexOf(cbPopFoods.getValue()) != 0) {
					tfExpDate.setStyle("-fx-text-inner-color: black;");
					int expTime = popExpDate[items.indexOf(cbPopFoods.getValue())];
					expCalendar.add(Calendar.DATE, expTime);
					tfExpDate.setText(expCalendar.get(Calendar.MONTH)+1 + "/" +
							expCalendar.get(Calendar.DATE) + "/" + expCalendar.get(Calendar.YEAR));
					cbFoodCategories.setValue(foodCategoryStrings[popFoodPicNo[items.indexOf(cbPopFoods.getValue())]]);
				}
				else {
					tfExpDate.setStyle("-fx-text-inner-color: gray;");
					tfExpDate.setText("mm/dd/yyyy");
				}
			}    
		});
		//changing the food categories combo box
		cbFoodCategories.valueProperty().addListener(new ChangeListener<String>() {
			@Override public void changed(ObservableValue ov, String t, String t1) {
				
				int temp = categoryItems.indexOf(cbFoodCategories.getValue());
				foodIV.setImage(foodImgs[temp]);
				double w = foodImgs[temp].getWidth();
				double h = foodImgs[temp].getHeight();
				double g = w;
				if (h > w)
					g = h;
				double r = g / 100.0;
				int nw = (int) Math.round(w / r);
				int nh = (int) Math.round(h / r);
				foodIV.setFitWidth(nw);
				foodIV.setFitHeight(nh);
			}
		});
		//changing the title of the food
		tfFood.setOnMouseClicked(e -> {
			tfFood.setStyle("-fx-text-inner-color: black;" + "-fx-background-color: white;");
			cbPopFoods.setStyle("-fx-background-color: white;");
			tfFood.setText("");
		});
		//done button
		donebtn.setOnAction(e -> {
			//check fields, make sure all information is valid
			Boolean test = true;
			if (("eg. Mayonnaise".equals(tfFood.getText()) || tfFood.getLength() == 0) && items.indexOf(cbPopFoods.getValue()) == 0) {
				tfFood.setStyle("-fx-background-color: red;");
				cbPopFoods.setStyle("-fx-background-color: red;");
				test = false;
			}
			if ("mm/dd/yyyy".equals(tfExpDate.getText()) || tfExpDate.getLength() == 0) {
				tfExpDate.setStyle("-fx-background-color: red;");
				errorLbl.setText("*Must enter an expiration date");
				test = false;
			} else if (isValidDate(tfExpDate.getText()).contains("*")) {
				tfExpDate.setStyle("-fx-background-color: red;");
				errorLbl.setText(isValidDate(tfExpDate.getText()));
				test = false;
			}
			if (test == true){
				String food = "";
				if ("eg. Mayonnaise".equals(tfFood.getText()) || tfFood.getLength() == 0) {
					food = cbPopFoods.getValue();
				} else {
					food = tfFood.getText();
				}
				try {
					writeToPantry(food, tfExpDate.getText(), foodStrings[categoryItems.indexOf(cbFoodCategories.getValue())]);
				} catch (Exception IOException) {
					System.out.println("File not Found");
				}
				addStage.close();
				
				Stage mainStage = new Stage();
				try{
					main.start(mainStage);
				}catch (Exception m){
					m.printStackTrace();
				}
			}
		});
		//cancel button
		cancelBtn.setOnAction(e -> {
			addStage.close();
			Stage mainStage = new Stage();
			try{
				main.start(mainStage);
			}catch (Exception m){
				m.printStackTrace();
			}
		});
		
		return pane;
	}
	
	public void writeToPantry(String food, String expDate, String imgFilePath) throws IOException{
		PrintWriter writer = new PrintWriter(new FileOutputStream(new File("pantry.txt"), true));
		writer.println(food + "$" + expDate + "%" + imgFilePath);
		writer.close();
	}
	
	public static String isValidDate(String inDate) {
		Date current = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		Date given = new Date();
		try {
			given = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return "*Date not formatted correctly\nCorrect format: (mm/dd/yyyy)";
		}
		if(given.after(current))
			return "true";
		else 
			return "*Item already expired";
	}
	
	@Override
		public void start(Stage primaryStage) throws MalformedURLException {
			addStage.setTitle("Add Items to Pantry List");
			Scene addScene = new Scene(addMenu(), 400, 500);
			addStage.setScene(addScene);
			addStage.setResizable(false);
			addStage.show();
		}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}